// Создать функциональный компонент Greeting, который выводит
// простое приветствие, например, <h1>Привет, React!</h1>.


// 1. Модифицировать компонент Greeting, чтобы он выводил различные
// приветствия в зависимости от времени суток, например, "Доброе утро" или
// "Добрый вечер", используя условный рендеринг.
// 2. Использовать new Date().getHours() для определения текущего времени и
// установить условие для отображения соответствующего приветствия.
// 3. Запустить приложение и проверить, что отображается соответствующее
// приветствие в зависимости от времени суток.

import React from 'react';

const Greeting = () => {
    const currentTime = new Date().getHours();
    if (currentTime > 4 && currentTime < 12) {
      return(<h1 style ={{textAlign: 'center'}}>Good morning, React!</h1>)
    } else if (currentTime > 11 && currentTime < 17) {
            return(
                <h1 style={{textAlign: 'center'}}>Good afternoon, React!</h1>
            )
        } else if (currentTime > 16 && currentTime < 23) {
            return(
                <h1 style={{textAlign: 'center'}}>Good evening, React!</h1>
            )
        } else {
            return(
                <h1 style={{textAlign: 'center'}}>Good night, React!</h1>
            )
        }
}

export default Greeting;