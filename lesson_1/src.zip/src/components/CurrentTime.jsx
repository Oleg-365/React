import React from "react";

const CurrentTime = () => {
    const date = new Date()
    return(
        <h2>Current time is : {date.toLocaleTimeString()}</h2>
    )
}

export default CurrentTime;