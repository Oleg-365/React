import React from "react";
import '../styles/App.css'

const EventCard = (props) => {
    return (
       <div className="event-card">
            <h2 className="event-card__name"> Event: {props.name}</h2>
            <span className="event-card__date">Date: {props.date}</span>
            <span className="event-card__place">Location: {props.location}</span>
       </div>
    )
}

export default EventCard; 

