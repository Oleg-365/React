// import CurrentTime from "./components/CurrentTime";
// import Greeting from "./components/Greeting";

import EventCard from "./components/EventCard";

function App() {
  return (
    <div className="App">
      <EventCard name="Wedding" date='25 December' location="Bahamas"/>

      <EventCard name="Gender party" date='10 October' location="Moscow"/>

      <EventCard name="Anna's b-day" date='2 March' location="Bali"/>
    </div>
  );
}

export default App;
